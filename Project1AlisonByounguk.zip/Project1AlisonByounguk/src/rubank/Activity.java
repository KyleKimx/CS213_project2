package rubank;

public class Activity implements Comparable<Activity> {
    private Date date;
    private Branch location; // the location of the activity
    private char type; // D or W
    private double amount;
    private boolean atm; // true if this is made at an ATM (from the text file)

    public Activity(Date date, Branch location, char type, double amount, boolean atm) {
        this.date = date;
        this.location = location;
        this.type = type;
        this.amount = amount;
        this.atm = atm;
    }

    public Date getDate() {
        return date;
    }

    public Branch getLocation() {
        return location;
    }

    public char getType() {
        return type;
    }

    public double getAmount() {
        return amount;
    }

    public boolean isAtm() {
        return atm;
    }

    @Override
    public int compareTo(Activity other) {
        return this.date.compareTo(other.date);
    }

    @Override
    public String toString() {
        return String.format("Activity[date=%s, location=%s, type=%c, amount=%.2f, atm=%b]",
                date, location, type, amount, atm);
    }
}