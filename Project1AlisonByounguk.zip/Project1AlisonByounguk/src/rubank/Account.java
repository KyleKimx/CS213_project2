package rubank;

import java.util.List;

public abstract class Account implements Comparable<Account> {
    protected AccountNumber number;
    protected Profile holder;
    protected double balance;
    protected List<Activity> activities; // list of account activities (D or W)

    public final void statement() { // Template Method; DO NOT modify
        printActivities(); // private helper method
        double interest = interest(); // polymorphism based on actual type
        double fee = fee(); // polymorphism based on actual type
        printInterestFee(interest, fee); // private helper method
        printBalance(interest, fee); // private helper method
    }

    private void printActivities() {
        for (Activity activity : activities) {
            System.out.println(activity);
        }
    }

    private void printInterestFee(double interest, double fee) {
        System.out.printf("Interest: %.2f, Fee: %.2f%n", interest, fee);
    }

    private void printBalance(double interest, double fee) {
        double updatedBalance = balance + interest - fee;
        System.out.printf("Updated Balance: %.2f%n", updatedBalance);
    }

    public void addActivity(Activity activity) {
        activities.add(activity);
    }

    public abstract double interest(); // monthly interest

    public abstract double fee(); // account fee

    @Override
    public int compareTo(Account other) {
        return this.number.compareTo(other.number);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Account other = (Account) obj;
        return this.holder.equals(other.holder) && this.number.equals(other.number);
    }

    @Override
    public String toString() {
        return String.format("Account#[%s] Holder[%s] Balance[$%.2f] Branch [%s]",
                number.toString(),
                holder.toString(),
                balance,
                number.getBranch().name()
        );
    }
}