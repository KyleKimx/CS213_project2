package rubank;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class TransactionManager {
    private final AccountDatabase accountDatabase;

    public TransactionManager() {
        accountDatabase = new AccountDatabase();
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Transaction Manager is running.");

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine().trim();
            if (line.isEmpty()) {
                continue;
            }

            String[] tokens = line.split("\\s+");
            String command = tokens[0];

            switch (command) {
                case "Q":
                    System.out.println("Transaction Manager is terminated.");
                    return;
                case "L":
                    loadAccounts(tokens);
                    break;
                case "A":
                    processActivities(tokens);
                    break;
                // Add other command cases here
                default:
                    System.out.println("Invalid command!");
                    break;
            }
        }
    }

    private void loadAccounts(String[] tokens) {
        if (tokens.length < 2) {
            System.out.println("Missing file name for loading accounts.");
            return;
        }
        String fileName = "E:\\CS213\\Project1AlisonByounguk\\" + tokens[1];
        try {
            accountDatabase.loadAccounts(fileName);
            System.out.println("Accounts loaded from " + fileName);
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + fileName);
        }
    }

    private void processActivities(String[] tokens) {
        if (tokens.length < 2) {
            System.out.println("Missing file name for processing activities.");
            return;
        }
        String fileName = "E:\\CS213\\Project1AlisonByounguk\\" + tokens[1];
        try {
            accountDatabase.processActivities(fileName);
            System.out.println("Activities processed from " + fileName);
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + fileName);
        }
    }
}