package rubank;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class AccountDatabase extends List<Account> {
    private Archive archive;

    public AccountDatabase() {
        super();
        this.archive = new Archive();
    }

    public void loadAccounts(String fileName) throws FileNotFoundException {
        File file = new File(fileName);
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (!line.isEmpty()) {
                    Account account = parseAccount(line);
                    add(account);
                }
            }
        }
    }

    public void processActivities(String fileName) throws FileNotFoundException {
        File file = new File(fileName);
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (!line.isEmpty()) {
                    processActivity(line);
                }
            }
        }
    }

    private Account parseAccount(String line) {
        String[] tokens = line.split(",");
        String accountType = tokens[0].toLowerCase();
        Branch branch = Branch.valueOf(tokens[1].toUpperCase());
        String firstName = tokens[2];
        String lastName = tokens[3];
        String dob = tokens[4];
        double balance = Double.parseDouble(tokens[5]);

        Profile holder = new Profile(firstName, lastName, new Date(dob));
        AccountNumber accountNumber = new AccountNumber(branch, AccountType.valueOf(accountType.toUpperCase()));

        switch (accountType) {
            case "checking":
                return new Checking(accountNumber, holder, balance);
            case "savings":
                return new Savings(accountNumber, holder, balance);
            case "moneymarket":
                return new MoneyMarket(accountNumber, holder, balance);
            case "college":
                Campus campus = Campus.valueOf(tokens[6]);
                return new CollegeChecking(accountNumber, holder, balance, campus);
            case "certificate":
                int term = Integer.parseInt(tokens[6]);
                Date openDate = new Date(tokens[7]);
                return new CertificateDeposit(accountNumber, holder, balance, term, openDate);
            default:
                throw new IllegalArgumentException("Invalid account type: " + accountType);
        }
    }

    private void processActivity(String line) {
        String[] tokens = line.split(",");
        char type = tokens[0].charAt(0);
        String accountNumber = tokens[1];
        double amount = Double.parseDouble(tokens[2]);

        Account account = findAccountByNumber(accountNumber);
        if (account != null) {
            Activity activity = new Activity(new Date(), Branch.valueOf(accountNumber.substring(0, 3)), type, amount, true);
            account.addActivity(activity);
            if (type == 'D') {
                account.deposit(amount);
            } else if (type == 'W') {
                account.withdraw(amount);
            }
        }
    }

    private Account findAccountByNumber(String accountNumber) {
        for (Account account : this) {
            if (account.getNumber().toString().equals(accountNumber)) {
                return account;
            }
        }
        return null;
    }
}